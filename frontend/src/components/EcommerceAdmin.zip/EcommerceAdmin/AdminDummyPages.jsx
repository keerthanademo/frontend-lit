import React from 'react';
import './DummyPage.css';

export const Analytics = () => <div className="dummy-page"><h2>Analytics</h2><p>Placeholder page.</p></div>;
export const Products = () => <div className="dummy-page"><h2>Products</h2><p>Placeholder page.</p></div>;
export const Offers = () => <div className="dummy-page"><h2>Offers</h2><p>Placeholder page.</p></div>;
export const Inventory = () => <div className="dummy-page"><h2>Inventory</h2><p>Placeholder page.</p></div>;
export const Orders = () => <div className="dummy-page"><h2>Orders</h2><p>Placeholder page.</p></div>;
export const Sales = () => <div className="dummy-page"><h2>Sales</h2><p>Placeholder page.</p></div>;
export const Customers = () => <div className="dummy-page"><h2>Customers</h2><p>Placeholder page.</p></div>;
export const Newsletter = () => <div className="dummy-page"><h2>Newsletter</h2><p>Placeholder page.</p></div>;
export const Settings = () => <div className="dummy-page"><h2>Settings</h2><p>Placeholder page.</p></div>;
